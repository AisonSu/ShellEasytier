# ShellEasytier

ShellEasytier is a Shell-based EasyTier orchestrator for Linux routers, OpenWrt,
Padavan-like firmware, Xiaomi/Redmi router environments, and generic Linux.

## Current Design Baseline

- Dual mode:
  - `local`: ShellEasytier renders local TOML and starts `easytier-core -c ...`
  - `remote`: ShellEasytier only manages service lifecycle, `--config-server`,
    `--machine-id`, status, logs, and optional local web console helpers
- Package source:
  - Linux release assets can be prepared on the developer machine into
    `pkg/<arch>/`
  - These binaries are for web hosting and runtime download, not for inclusion
    inside the release tarball
- Web capability:
  - If `pkg/<arch>/easytier-web-embed` exists, local embedded web console can be
    offered in menu
  - If it does not exist, web console entries stay hidden
- Space-aware layout:
  - Core + CLI are treated as the minimal runtime set
  - Web binaries are optional and enabled only when both package capability and
    storage profile allow it

## Developer Workflow

1. Run `./prepare_pkg.sh [version]` on the local developer machine.
2. The script downloads EasyTier Linux release assets and expands them into
   `pkg/<arch>/`.
3. Host `pkg/` on your HTTP server for runtime binary download.
4. Run `./pack_release.sh` to build `ShellEasytier.tar.gz`.
5. Installers download only `ShellEasytier.tar.gz`.
6. Runtime scripts detect architecture and download `easytier-core`,
   `easytier-cli`, and optional `easytier-web-embed` from
   `update_url/pkg/<arch>/`.

## Supported Linux Package Architectures

- `x86_64`
- `aarch64`
- `arm`
- `armhf`
- `armv7`
- `armv7hf`
- `mips`
- `mipsel`

Optional future expansion:

- `loongarch64`
- `riscv64`

## Runtime Storage Strategy

ShellEasytier should not assume that all targets can keep full runtime payloads
on persistent storage.

- If persistent storage is large enough, keep current-arch binaries under a
  persistent runtime directory.
- If persistent storage is tight but `/tmp` is large enough, stage binaries to
  tmpfs and keep only configs on flash.
- If `web-embed` exists but storage is too small, start only core + cli and hide
  local web menu entries.

This keeps the routing and embedded targets usable while still allowing richer
Linux hosts to expose the local web console.
